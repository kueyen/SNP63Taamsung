<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FoodExtra extends Model
{
    //
}
