<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BillDetailExtra extends Model
{
    //
}
