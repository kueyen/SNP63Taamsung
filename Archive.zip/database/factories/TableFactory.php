<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\table;
use Faker\Generator as Faker;

$factory->define(table::class, function (Faker $faker) {
    return [
        //
    ];
});
