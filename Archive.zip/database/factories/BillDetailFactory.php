<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\BillDetail;
use Faker\Generator as Faker;

$factory->define(BillDetail::class, function (Faker $faker) {
    return [
        //
    ];
});
