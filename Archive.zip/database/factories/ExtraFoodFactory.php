<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ExtraFood;
use Faker\Generator as Faker;

$factory->define(ExtraFood::class, function (Faker $faker) {
    return [
        //
    ];
});
