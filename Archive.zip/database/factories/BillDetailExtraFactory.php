<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\BillDetailExtra;
use Faker\Generator as Faker;

$factory->define(BillDetailExtra::class, function (Faker $faker) {
    return [
        //
    ];
});
