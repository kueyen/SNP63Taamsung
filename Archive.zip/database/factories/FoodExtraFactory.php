<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\FoodExtra;
use Faker\Generator as Faker;

$factory->define(FoodExtra::class, function (Faker $faker) {
    return [
        //
    ];
});
